﻿namespace Ex05.GUI
{
    public class Program
    {
        public static void Main()
        {
            Manager manager = new Manager();
            manager.Run();
        }
    }
}